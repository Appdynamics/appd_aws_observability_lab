#!/bin/bash

echo "CloudWorkshop|INFO|     - Deploying Application to the EKS Cluster"

cd /home/ec2-user/environment/deployment

kubectl create -f post-mod-kube-app/

# Wait 30 seconds : 30 secs
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .............................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..........................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .........................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ....................................................."
sleep 3
# Wait 30 seconds : 1 min
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ...................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..............................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .............................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..........................................."
sleep 3
# Wait 30 seconds : 1.5 mins
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .........................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ....................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ...................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .................................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................................."
sleep 3
# Wait 30 seconds : 2 mins
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..............................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .............................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..........................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .........................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................."
sleep 3
# Wait 30 seconds : 2.5 mins
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ....................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ...................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ................"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..............."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .............."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............."
sleep 3
# Wait 30 seconds : 3 mins
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ............"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..........."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .........."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ........"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ......"
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ....."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ...."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize ..."
sleep 3
echo "CloudWorkshop|INFO|     - Waiting for Application to Initialize .."

