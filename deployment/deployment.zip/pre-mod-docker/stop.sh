#!/usr/bin/env bash

echo "Stopping application..."

cd /home/ec2-user/environment/deployment/pre-mod-docker

docker-compose down