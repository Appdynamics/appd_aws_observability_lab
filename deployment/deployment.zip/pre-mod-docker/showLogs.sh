#!/usr/bin/env bash

docker-compose logs -f $@