#!/bin/bash

eksctl create cluster -f /home/ec2-user/environment/deployment/post-mod-kube-cluster/cluster.yaml

